package com.linkai.codeeditor.config;

import com.linkai.codeeditor.socket.CodeEditorSocket;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@Configuration
@EnableWebSocket
public class SocketConfig implements WebSocketConfigurer {

    @Bean
    public CodeEditorSocket codeEditorSocket(){
        return new CodeEditorSocket();
    }

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        registry
                .addHandler(codeEditorSocket(), "/code-editor")
                .setAllowedOrigins("*");
    }
}
