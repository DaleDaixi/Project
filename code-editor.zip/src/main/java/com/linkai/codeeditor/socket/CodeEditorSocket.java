package com.linkai.codeeditor.socket;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.linkai.codeeditor.domain.ProjectFile;
import com.linkai.codeeditor.service.CodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.security.Key;
import java.util.*;

public class CodeEditorSocket extends TextWebSocketHandler {

    @Autowired
    private CodeService codeService;
    @Autowired
    private ObjectMapper objectMapper;

    public static final Map<Integer, List<WebSocketSession>> sessionsMap = new HashMap<>();
    private static final Set<String> hasInit = new HashSet<>();


    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        String payload = message.getPayload();
        if (hasInit.contains(session.getId())) {
            ProjectFile readChangeFile = objectMapper.readValue(payload, ProjectFile.class);
            codeService.updateFile(readChangeFile);
            for (WebSocketSession s : sessionsMap.get(readChangeFile.getId())) {
                HashMap<Object, Object> data = new HashMap<>();
                data.put("fileId", readChangeFile.getId());
                data.put("type", "refresh");
                data.put("content", readChangeFile.getContent());
                data.put("fileName", readChangeFile.getFileName());
                s.sendMessage(new TextMessage(objectMapper.writeValueAsString(data)));
            }
        } else {
            int fileId = Integer.parseInt(payload);
            hasInit.add(session.getId());
            sessionsMap.compute(fileId, (key, list) -> {
                if (list == null) list = new ArrayList<>();
                list.add(session);
                return list;
            });
        }

    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        super.afterConnectionEstablished(session);
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        hasInit.remove(session.getId());
        for (Integer key : sessionsMap.keySet()) {
            sessionsMap.get(key).remove(session);
        }
    }
}
