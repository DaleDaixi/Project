package com.linkai.codeeditor.mapper;

import com.linkai.codeeditor.domain.ProjectFile;

import java.util.List;

public interface ProjectFileMapper {

    List<ProjectFile> selectList(Integer projectId);

    int deleteByPrimaryKey(Integer id);

    int insert(ProjectFile record);

    int insertSelective(ProjectFile record);

    ProjectFile selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ProjectFile record);

    int updateByPrimaryKey(ProjectFile record);
}
