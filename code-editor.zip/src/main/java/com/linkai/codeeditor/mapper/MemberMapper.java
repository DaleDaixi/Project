package com.linkai.codeeditor.mapper;

import com.linkai.codeeditor.domain.Member;

import java.util.List;

public interface MemberMapper {
    List<Member> selectList();

    int deleteByPrimaryKey(Integer id);

    int insert(Member record);

    int insertSelective(Member record);

    Member selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Member record);

    int updateByPrimaryKey(Member record);

    Member selectByUsername(String username);
}
