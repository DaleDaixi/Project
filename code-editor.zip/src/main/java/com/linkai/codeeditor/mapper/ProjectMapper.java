package com.linkai.codeeditor.mapper;

import com.linkai.codeeditor.domain.Project;
import com.linkai.codeeditor.domain.ProjectMember;

import java.util.List;

public interface ProjectMapper {

    List<Project> listByProject(Integer memberId);

    List<ProjectMember> listProjectMember(Integer projectId);

    int deleteByPrimaryKey(Integer id);

    int insert(Project record);

    int insertSelective(Project record);

    Project selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Project record);

    int updateByPrimaryKey(Project record);
}
