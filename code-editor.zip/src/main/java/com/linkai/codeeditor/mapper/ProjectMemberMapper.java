package com.linkai.codeeditor.mapper;

import com.linkai.codeeditor.domain.ProjectMember;

public interface ProjectMemberMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ProjectMember record);

    int insertSelective(ProjectMember record);

    ProjectMember selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ProjectMember record);

    int updateByPrimaryKey(ProjectMember record);
}