package com.linkai.codeeditor.service.impl;

import com.linkai.codeeditor.domain.Member;
import com.linkai.codeeditor.mapper.MemberMapper;
import com.linkai.codeeditor.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class MemberServiceImpl implements MemberService {

    @Autowired
    private MemberMapper memberMapper;

    @Override
    public Member memberLogin(String username, String password) {
        Member member = memberMapper.selectByUsername(username);
        if (member != null) {
            if (member.getPassword().equals(password)) {
                return member;
            } else {
                throw new RuntimeException("The user does not exist. Please log in again!");
            }
        } else {
            throw new RuntimeException("The user does not exist. Please log in again!");
        }
    }

    @Override
    public int registerMember(Member member) {
        member.setCreateTime(new Date());
        member.setCreateBy(member.getUsername());
        try {
            return memberMapper.insertSelective(member);
        } catch (Exception e) {
            throw new RuntimeException("The email address or user name already exists");
        }
    }

    @Override
    public List<Member> getMemberList() {
        return memberMapper.selectList();
    }
}
