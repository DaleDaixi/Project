package com.linkai.codeeditor.service;

import com.linkai.codeeditor.domain.Member;

import java.util.List;

public interface MemberService {

    /**
     * Login
     *
     * @param username 账户
     * @param password 密码
     * @return 是否登陆成功
     */
    Member memberLogin(String username, String password);

    /**
     * 注册
     *
     * @param member 账户
     * @return 是否注册成功
     */
    int registerMember(Member member);

    List<Member> getMemberList();

}
