package com.linkai.codeeditor.service;

import com.linkai.codeeditor.domain.Project;
import com.linkai.codeeditor.domain.ProjectMember;

import java.util.List;

public interface ProjectService {


    List<Project> listByProject(Integer memberId);

    int createProject(Project project);

    Project getProject(Integer projectId);

    List<ProjectMember> getProjectMembers(Integer projectId);

    int deleteProjectMember(Integer projectMemberId);

    int addProjectMember(ProjectMember projectMember);

    int updateProject(Project project);
}
