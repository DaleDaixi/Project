package com.linkai.codeeditor.service;

import com.linkai.codeeditor.domain.ProjectFile;

import java.util.List;

public interface CodeService {

    List<ProjectFile> getFiles(Integer projectId);

    ProjectFile getFile(Integer fileId);

    int updateFile(ProjectFile file);

    int deleteFile(Integer fileId);

    int createFile(ProjectFile file);
}
