package com.linkai.codeeditor.service.impl;

import com.linkai.codeeditor.domain.ProjectFile;
import com.linkai.codeeditor.mapper.ProjectFileMapper;
import com.linkai.codeeditor.service.CodeService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class CodeServiceImpl implements CodeService {

    @Resource
    private ProjectFileMapper fileMapper;

    @Override
    public List<ProjectFile> getFiles(Integer projectId) {
        return fileMapper.selectList(projectId);
    }

    @Override
    public ProjectFile getFile(Integer fileId) {
        return fileMapper.selectByPrimaryKey(fileId);
    }

    @Override
    public int updateFile(ProjectFile file) {
        file.setUpdateTime(new Date());
        return fileMapper.updateByPrimaryKeySelective(file);
    }

    @Override
    public int deleteFile(Integer fileId) {
        return fileMapper.deleteByPrimaryKey(fileId);
    }

    @Override
    public int createFile(ProjectFile file) {
        file.setCreateTime(new Date());
        return fileMapper.insertSelective(file);
    }
}
