package com.linkai.codeeditor.service.impl;

import com.linkai.codeeditor.domain.Project;
import com.linkai.codeeditor.domain.ProjectMember;
import com.linkai.codeeditor.mapper.ProjectMapper;
import com.linkai.codeeditor.mapper.ProjectMemberMapper;
import com.linkai.codeeditor.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class ProjectServiceImpl implements ProjectService {

    @Autowired
    private ProjectMapper projectMapper;
    @Autowired
    private ProjectMemberMapper projectMemberMapper;

    @Override
    public List<Project> listByProject(Integer memberId) {
        return projectMapper.listByProject(memberId);
    }

    @Override
    public int createProject(Project project) {
        project.setCreateTime(new Date());
        return projectMapper.insertSelective(project);
    }

    @Override
    public Project getProject(Integer projectId) {
        return projectMapper.selectByPrimaryKey(projectId);
    }

    @Override
    public List<ProjectMember> getProjectMembers(Integer projectId) {
        return projectMapper.listProjectMember(projectId);
    }

    @Override
    public int deleteProjectMember(Integer projectMemberId) {
        return projectMemberMapper.deleteByPrimaryKey(projectMemberId);
    }

    @Override
    public int addProjectMember(ProjectMember projectMember) {
        projectMember.setCreateTime(new Date());
        return projectMemberMapper.insertSelective(projectMember);
    }

    @Override
    public int updateProject(Project project) {
        project.setUpdateTime(new Date());
        return projectMapper.updateByPrimaryKeySelective(project);
    }
}
