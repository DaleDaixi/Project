package com.linkai.codeeditor;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@MapperScan("com.linkai.codeeditor.mapper")
@SpringBootApplication
public class CodeEditorApplication {

    public static void main(String[] args) {
        SpringApplication.run(CodeEditorApplication.class, args);
    }

}
