package com.linkai.codeeditor.controller;

import com.linkai.codeeditor.domain.Member;
import com.linkai.codeeditor.domain.Project;
import com.linkai.codeeditor.domain.ProjectMember;
import com.linkai.codeeditor.service.MemberService;
import com.linkai.codeeditor.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@RequestMapping("project")
@Controller
public class ProjectController {

    @Autowired
    private ProjectService projectService;
    @Autowired
    private MemberService memberService;

    @GetMapping(path = {"/index", ""})
    public String projectIndex(HttpSession session, Model model, String projectId) {
        Integer memberId = (Integer) session.getAttribute("memberId");
        model.addAttribute("list", projectService.listByProject(memberId));
        if (Objects.nonNull(projectId)) {
            if (projectId.equals("0")) {
                model.addAttribute("addForm", new Project());
            } else {
                Project project = projectService.getProject(Integer.parseInt(projectId));
                model.addAttribute("updateForm", project);
                if (project.getCreateBy().equals(String.valueOf(session.getAttribute("memberId")))) {
                    List<ProjectMember> projectMembers = projectService.getProjectMembers(project.getId());
                    List<Member> memberList = memberService.getMemberList().stream().filter(member -> {
                        if (project.getCreateBy().equals(String.valueOf(member.getId()))) {
                            return false;
                        } else {
                            for (ProjectMember projectMember : projectMembers) {
                                if (projectMember.getMemberId().equals(member.getId())) return false;
                            }
                        }

                        return true;
                    }).collect(Collectors.toList());
                    model.addAttribute("projectMembers", projectMembers);
                    model.addAttribute("memberList", memberList);
                }
            }
        }
        return "/project";
    }

    @GetMapping(path = "/delMember")
    public String deleteProjectMember(Integer projectId, Integer projectMemberId) {
        projectService.deleteProjectMember(projectMemberId);
        return "redirect:/project?projectId=" + projectId;
    }

    @PostMapping(path = "/addMember")
    public String addProjectMember(ProjectMember projectMember, HttpSession session) {
        projectMember.setCreateBy(String.valueOf(session.getAttribute("memberId")));
        projectService.addProjectMember(projectMember);
        return "redirect:/project?projectId=" + projectMember.getProjectId();
    }

    @PostMapping(path = {"/create"})
    public String createProject(HttpSession session, Model model, Project project) {
        Integer memberId = (Integer) session.getAttribute("memberId");
        project.setCreateBy(String.valueOf(memberId));
        if (projectService.createProject(project) > 0) {
            model.addAttribute("success", "create project successfully");
        } else {
            model.addAttribute("error", "create project fail!");
        }
        return "redirect:/project";
    }

    @PostMapping(path = {"/update"})
    public String updateProject(HttpSession session, Project project) {
        project.setUpdateBy(String.valueOf(session.getAttribute("memberId")));
        projectService.updateProject(project);
        return "redirect:/project?projectId=" + project.getId();
    }
}
