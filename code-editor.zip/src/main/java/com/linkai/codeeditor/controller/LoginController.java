package com.linkai.codeeditor.controller;

import com.linkai.codeeditor.domain.Member;
import com.linkai.codeeditor.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpSession;

@Controller
public class LoginController {
    @Autowired
    private MemberService memberService;

    @GetMapping(path = {"/login", "/"})
    public String login() {
        return "/login";
    }

    @GetMapping(path = {"/register"})
    public String register() {
        return "/register";
    }

    @PostMapping(path = {"/handleLogin"})
    public String handleLogin(String username, String password, HttpSession session, Model model) {

        try {
            Member member = memberService.memberLogin(username, password);
            session.setAttribute("memberId", member.getId());
            session.setAttribute("username", member.getUsername());
            session.setAttribute("email", member.getEmail());
            return "redirect:/project";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "/login";
        }
    }

    @GetMapping(path = {"/logout"})
    public String handleLogout(HttpSession session, Model model) {
        session.invalidate();
        model.addAttribute("success", "logout successfully!");
        return "/login";
    }

    @PostMapping(path = {"/handleRegister"})
    public String handleRegister(Member member, Model model) {
        try {
            memberService.registerMember(member);
            model.addAttribute("success", "register successfully!");
            return "/login";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "/register";
        }
    }
}
