package com.linkai.codeeditor.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.linkai.codeeditor.domain.ProjectFile;
import com.linkai.codeeditor.service.CodeService;
import com.linkai.codeeditor.socket.CodeEditorSocket;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;

import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping(path = {"/code"})
public class CodeController {

    @Autowired
    private CodeService codeService;
    @Autowired
    private ObjectMapper objectMapper;

    @GetMapping(path = {"/", "", "/index"})
    public String codeIndex(Integer projectId, Model model) {
        List<ProjectFile> files = codeService.getFiles(projectId);
        model.addAttribute("files", files);
        model.addAttribute("projectId", projectId);
        return "/code";
    }

    @GetMapping(path = {"/edit"})
    public String editFile(Integer fileId, Model model) {
        ProjectFile file = codeService.getFile(fileId);
        Integer projectId = file.getProjectId();
        model.addAttribute("file", file);
        List<ProjectFile> files = codeService.getFiles(projectId);
        model.addAttribute("files", files);
        model.addAttribute("projectId", projectId);
        return "/editCode";
    }

    @PostMapping(path = {"/create"})
    public String createFile(ProjectFile file, HttpSession session) {
        file.setCreateBy(String.valueOf(session.getAttribute("memberId")));
        codeService.createFile(file);
        return "redirect:/code?projectId=" + file.getProjectId();
    }

    @GetMapping(path = {"/delete"})
    public String deleteFile(Integer fileId) {
        ProjectFile file = codeService.getFile(fileId);
        codeService.deleteFile(fileId);
        Map<Integer, List<WebSocketSession>> sessionsMap = CodeEditorSocket.sessionsMap;
        if (sessionsMap.containsKey(fileId)) {
            for (WebSocketSession session : sessionsMap.get(fileId)) {
                try {
                    HashMap<Object, Object> data = new HashMap<>();
                    data.put("type", "delete");
                    session.sendMessage(new TextMessage(objectMapper.writeValueAsString(data)));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            sessionsMap.remove(fileId);
        }

        return "redirect:/code?projectId=" + file.getProjectId();
    }
}
